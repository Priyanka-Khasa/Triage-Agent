import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class LocalRetriever:
    def __init__(self, data_dir: str):
        """
        Initializes the local retriever using TF-IDF and cosine similarity.
        """
        self.data_dir = data_dir
        self.chunks = []
        self.vectorizer = TfidfVectorizer(stop_words='english', lowercase=True)
        self.tfidf_matrix = None
        
    def _chunk_text(self, text: str, filepath: str):
        """
        Chunks text by paragraphs, combining them until a length threshold is reached.
        """
        paragraphs = text.split('\n\n')
        chunks = []
        current_chunk = ""
        max_chunk_size = 1000 # characters
        
        for p in paragraphs:
            # Clean up the paragraph
            p = p.strip()
            if not p:
                continue
                
            if len(current_chunk) + len(p) > max_chunk_size:
                if current_chunk:
                    chunks.append({
                        "text": current_chunk.strip(), 
                        "filepath": filepath,
                        "company": self._infer_company(filepath)
                    })
                current_chunk = p
            else:
                if current_chunk:
                    current_chunk += "\n\n" + p
                else:
                    current_chunk = p
                    
        if current_chunk.strip():
            chunks.append({
                "text": current_chunk.strip(), 
                "filepath": filepath,
                "company": self._infer_company(filepath)
            })
            
        return chunks

    def _infer_company(self, filepath: str) -> str:
        """
        Infer the company from the file path.
        """
        path_lower = filepath.lower()
        if 'hackerrank' in path_lower:
            return 'HackerRank'
        elif 'claude' in path_lower:
            return 'Claude'
        elif 'visa' in path_lower:
            return 'Visa'
        return 'None'

    def build_index(self):
        """
        Reads all markdown files, chunks them, and builds the TF-IDF matrix.
        """
        for root, _, files in os.walk(self.data_dir):
            for file in files:
                if file.endswith('.md'):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8') as f:
                            text = f.read()
                            self.chunks.extend(self._chunk_text(text, filepath))
                    except Exception as e:
                        print(f"Error reading {filepath}: {e}")
                        
        if not self.chunks:
            raise ValueError("No markdown files found in the data directory.")
            
        corpus = [chunk['text'] for chunk in self.chunks]
        self.tfidf_matrix = self.vectorizer.fit_transform(corpus)

    def retrieve(self, query: str, top_k: int = 5, threshold: float = 0.15):
        """
        Retrieves the top_k chunks for the given query.
        Calculates a confidence score and sets an escalate flag if it's below the threshold.
        """
        if self.tfidf_matrix is None:
            raise RuntimeError("Index not built. Call build_index() first.")
            
        # Handle empty queries safely
        if not query or not query.strip():
            return {
                "results": [],
                "confidence": 0.0,
                "escalate": True
            }
            
        query_vec = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        
        # Get top K indices
        top_indices = similarities.argsort()[-top_k:][::-1]
        
        results = []
        for idx in top_indices:
            score = similarities[idx]
            # Even if score is 0, we can add it, but it's better to filter or let the caller see
            results.append({
                "text": self.chunks[idx]["text"],
                "filepath": self.chunks[idx]["filepath"],
                "company": self.chunks[idx]["company"],
                "score": float(score)
            })
            
        # The confidence score is the highest cosine similarity
        confidence = float(max(similarities)) if len(similarities) > 0 else 0.0
        
        # If the highest similarity is below our threshold, the system is not confident
        should_escalate = confidence < threshold
        
        return {
            "results": results,
            "confidence": confidence,
            "escalate": should_escalate
        }
