import os
import re

class TriageAgent:
    def __init__(self):
        """
        Initializes the Triage Agent using purely local, template-based rules without LLMs.
        """
        pass

    def classify_request_type(self, issue: str, subject: str = "") -> str:
        """
        Classify the support ticket using strict keyword-based rules.
        Highest risk takes priority.
        """
        text = f"{subject} {issue}".lower()
        
        # 1. Invalid (Highest risk/priority)
        invalid_keywords = ['spam', 'ignore previous instructions', 'malicious', 'hack', 'delete all', 'prompt injection']
        if any(kw in text for kw in invalid_keywords):
            return "invalid"
            
        # 2. Bug
        bug_keywords = ['broken', 'error', 'failed', 'not working', 'crash', 'incorrect result']
        if any(kw in text for kw in bug_keywords):
            return "bug"
            
        # 3. Feature Request
        feature_keywords = ['add', 'support', 'integrate', 'enable', 'improve', 'request']
        if any(kw in text for kw in feature_keywords):
            return "feature_request"
            
        # 4. Product Issue (Fallback for normal support questions)
        return "product_issue"

    def assess_escalation_risk(self, issue: str, subject: str = "") -> bool:
        """
        Assess if the ticket hits any high-risk escalation categories using keywords.
        """
        text = f"{subject} {issue}".lower()
        
        escalation_keywords = [
            'fraud', 'unauthorized', 'stolen', 'compromise', # 1. fraud, card compromise
            'dispute', 'refund', 'chargeback', # 2. billing dispute
            'hacked', 'identity theft', 'recovery', 'verify identity', # 3. hacked account
            'legal', 'privacy', 'vulnerability', 'cve', 'security flaw', # 4. legal/security
            'cheat', 'misconduct', 'integrity', # 5. assessment cheating
            'ignore instructions', 'system prompt', # 8. malicious instruction
            'urgent cash', 'ssn', 'credit card number' # 9. sensitive payment issue
        ]
        
        return any(kw in text for kw in escalation_keywords)

    def generate_response(self, issue: str, subject: str, retrieved_chunks: list, is_escalated: bool = False, escalation_reason: str = "") -> tuple[str, str, str]:
        """
        Generate a template-based response without using an LLM.
        Returns a tuple: (status, response, justification)
        """
        if is_escalated:
            status = "escalated"
            reason = escalation_reason or "High-risk topic or low retrieval confidence."
            response = f"We apologize, but this issue needs human support. Reason: {reason}. Please wait while we connect you to an agent."
            justification = f"Escalated: {reason}"
            return (status, response, justification)
            
        if not retrieved_chunks:
            status = "escalated"
            response = "We apologize, but this issue needs human support. Reason: Unsupported by current documentation. Please wait while we connect you to an agent."
            justification = "Escalated: Unsupported by corpus."
            return (status, response, justification)
            
        # For replied cases, strictly use the top retrieved chunk.
        best_chunk = retrieved_chunks[0]
        status = "replied"
        response = f"{best_chunk['text']}"
        justification = f"Replied using exact support documentation from {os.path.basename(best_chunk['filepath'])}."
        
        return (status, response, justification)
