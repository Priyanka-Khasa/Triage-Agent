import os
import csv
import pandas as pd

from retriever import LocalRetriever
from agent import TriageAgent

def main():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "data")
    input_csv = os.path.join(base_dir, "support_tickets", "support_tickets.csv")
    output_csv = os.path.join(base_dir, "support_tickets", "output.csv")
    execution_log_path = os.path.join(base_dir, "log.txt")
    
    # Initialize components
    print("Building local index...")
    retriever = LocalRetriever(data_dir=data_dir)
    retriever.build_index()
    
    print("Initializing TriageAgent...")
    agent = TriageAgent()
    
    df = pd.read_csv(input_csv)
    output_rows = []
    
    with open(execution_log_path, "w", encoding="utf-8") as log_file:
        for idx, row in df.iterrows():
            issue = str(row.get('Issue', ''))
            subject = str(row.get('Subject', ''))
            company = str(row.get('Company', 'None'))
            
            row_num = idx + 1
            print(f"Processing ticket {row_num}/{len(df)}...")
            
            # 1. Classify request type
            request_type = agent.classify_request_type(issue, subject)
            
            # 2. Determine Product Area
            product_area = company if company and company.lower() != 'none' else "General"
            
            retrieved_files = "None"
            confidence = "0.0"
            status = ""
            justification = ""
            response = ""
            
            # 3. Escalation Check 1: High-risk heuristics
            is_high_risk = agent.assess_escalation_risk(issue, subject)
            
            if is_high_risk:
                status, response, justification = agent.generate_response(
                    issue, subject, [], is_escalated=True, escalation_reason="Ticket hits high-risk escalation categories"
                )
            else:
                # 4. Retrieval
                query = f"{company} {subject} {issue}" if company and company.lower() != 'none' else f"{subject} {issue}"
                retrieval_res = retriever.retrieve(query, top_k=5, threshold=0.15)
                
                confidence = f"{retrieval_res['confidence']:.4f}"
                if retrieval_res['results']:
                    retrieved_files = ", ".join([os.path.basename(r['filepath']) for r in retrieval_res['results']])
                
                if retrieval_res["escalate"]:
                    status, response, justification = agent.generate_response(
                        issue, subject, [], is_escalated=True, escalation_reason="Low retrieval confidence (unsupported query)"
                    )
                else:
                    # 5. Generation
                    status, response, justification = agent.generate_response(issue, subject, retrieval_res["results"])
            
            # Write to execution log
            log_entry = f"Row: {row_num}\n"
            log_entry += f"Company: {company}\n"
            log_entry += f"Subject: {subject}\n"
            log_entry += f"Request Type: {request_type}\n"
            log_entry += f"Product Area: {product_area}\n"
            log_entry += f"Status: {status}\n"
            log_entry += f"Retrieved Source Files: {retrieved_files}\n"
            log_entry += f"Confidence Score: {confidence}\n"
            log_entry += f"Final Justification: {justification}\n"
            log_entry += "-" * 40 + "\n"
            log_file.write(log_entry)
            
            output_rows.append({
                "issue": issue,
                "subject": subject,
                "company": company,
                "response": response,
                "product_area": product_area,
                "status": status,
                "request_type": request_type,
                "justification": justification
            })
            
    print(f"Writing {len(output_rows)} rows to {output_csv}...")
    out_df = pd.DataFrame(output_rows)
    # Ensure correct column order
    cols = ['issue', 'subject', 'company', 'response', 'product_area', 'status', 'request_type', 'justification']
    out_df = out_df[cols]
    out_df.to_csv(output_csv, index=False)
    print(f"Execution log written to {execution_log_path}")
    print("Done!")

if __name__ == "__main__":
    main()
